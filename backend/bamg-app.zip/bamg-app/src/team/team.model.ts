import { Prisma } from "@prisma/client";


export class Team {
    id: number;
    teamOptaId: String;
    name: String;
    coachOptaId: String;
    //player: player[];
}