import { TeamService } from "./team.sevice";
import { Team } from "./team.model";
import { Body, Controller, Delete, Get, Param, Post, Put } from "@nestjs/common";

@Controller('api/v1/team')
export class TeamController{

    constructor(private readonly teamService: TeamService){}

    @Get()
    async getAllTeams(): Promise<Team[]>{
        return this.teamService.getAllTeams()
    }

    @Post()
    async postTeam(@Body() postData: Team):Promise<Team>{
        return this.teamService.createTeam(postData)
    }

    @Get(':id')
    async getTeam(@Param('id') id:number): Promise<Team | null>{
        return this.teamService.getTeam(id)
    }

    @Delete(':id')
    async deleteTeam(@Param('id') id:number): Promise<Team>{
        return this.teamService.deleteTeam(id)
    }

    @Put(':id')
    async updateTeam(@Param('id') id:number,@Body() postData: Team):Promise<Team>{
        return this.teamService.updateTeam(id, postData)
    }
}