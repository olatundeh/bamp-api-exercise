import { PrismaService } from "src/prisma.service";
import { Team } from "./team.model";
import { Injectable } from "@nestjs/common";
import { PrismaClient } from "@prisma/client";
import { Prisma } from "@prisma/client";

const prisma = new PrismaClient();

@Injectable()
export class TeamService{
    constructor(private prisma: PrismaService){}

    async getAllTeams(): Promise<Team[]>{
        return this.prisma.team.findMany()
    }

    async getTeam(id:number): Promise<Team | null>{
        return this.prisma.team.findUnique({where: {id:Number(id)}})
    }
    
    async createTeam(data: Team): Promise<Team> {
        const createData: Prisma.TeamCreateInput = {
          teamOptaId: data.teamOptaId.toString(), // Convert to primitive string
          name: data.name.toString(), // Convert to primitive string
          coachOptaId: data.coachOptaId?.toString(), // Convert to primitive string (optional)
        };
      
        return this.prisma.team.create({
          data: createData,
        });
    }

    async updateTeam(id: number, data: Team): Promise<Team> {
        return this.prisma.team.update({
          where: { id: Number(id) },
          data: {
            teamOptaId: {
              set: data.teamOptaId.toString(), // Use toString() to convert to primitive string
            },
            name: {
              set: data.name.toString(), // Use toString() to convert to primitive string
            },
            coachOptaId: {
              set: data.coachOptaId.toString(), // Use toString() to convert to primitive string
            },
          },
        });
    }      
      
    async deleteTeam(id:number): Promise<Team>{
        return this.prisma.team.delete({
            where: {id:Number(id)}
        })
    }
}