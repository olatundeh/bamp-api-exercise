import { Module } from "@nestjs/common";
import { TeamController } from "./team.controller";
import { TeamService } from "./team.sevice";
import { PrismaService } from "src/prisma.service";


@Module({
    controllers: [TeamController], 
    providers: [TeamService, PrismaService]
})
export class TeamModule{}