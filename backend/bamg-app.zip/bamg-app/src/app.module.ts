import { Module } from '@nestjs/common';
import { TeamModule } from './team/team.module';
import { TeamController } from './team/team.controller';
import { TeamService } from './team/team.sevice';
import { PrismaService } from './prisma.service';


@Module({
  imports: [TeamModule],
  controllers: [TeamController],
  providers: [TeamService, PrismaService],
})
export class AppModule {}
